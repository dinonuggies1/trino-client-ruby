# Security Policy

## Supported Versions

The current release is the supported version. Security fixes are released together
with all other fixes in each new release.

## Reporting a Vulnerability

Please report security vulnerabilities to **security@trino.io**.
